export default class LinkedListNode {
    constructor(value, next) {
        this.value = value;
        this.next = next ? next : null;
    }
}