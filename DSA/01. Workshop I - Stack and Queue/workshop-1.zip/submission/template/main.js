import Queue from './src/queue.js';

// for local testing

const queue = new Queue();

queue.enqueue(5);

console.log(queue.peek());

