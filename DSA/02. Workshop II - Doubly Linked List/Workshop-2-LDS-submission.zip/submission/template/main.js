// for local testing

import DoublyLinkedList from "./src/doubly-linked-list.js";

const DLL = new DoublyLinkedList();

DLL.addFirst(1);
DLL.addFirst(2);
DLL.addFirst(3);

const node = DLL.find(2);

DLL.insertBefore(node, 5);

console.log(DLL.values());
