/** The Board class holds tasks */
export class Board {

}