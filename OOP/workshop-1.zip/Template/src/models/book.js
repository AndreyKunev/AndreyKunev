import { bookGenre } from '../common/book-genre.js';

export class Book {

}
