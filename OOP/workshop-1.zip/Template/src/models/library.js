import { libraryShelf } from '../common/library-shelf.js';

export class Library {

}
