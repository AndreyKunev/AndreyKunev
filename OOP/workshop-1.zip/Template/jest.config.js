export default {
  verbose: true,
  transform: {
    '^.+\\.jsx?$': 'babel-jest',
  },
};
