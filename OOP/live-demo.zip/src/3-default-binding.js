// default

function logThis(){
  console.log(this);
}

logThis();