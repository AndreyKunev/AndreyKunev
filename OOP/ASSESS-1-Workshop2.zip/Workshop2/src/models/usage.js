export const Usage = {
  EveryDay: 'EveryDay',
  Medical: 'Medical',
};
