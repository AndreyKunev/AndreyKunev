export const Gender = {
  Men: 'Men',
  Women: 'Women',
  Unisex: 'Unisex',
};
