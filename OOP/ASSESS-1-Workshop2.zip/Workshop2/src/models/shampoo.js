import { Product } from './product.js';
import { Usage } from './usage.js';
import { Gender } from './gender.js';

export class Shampoo extends Product {

  static #minMilliliters = 0;

  #milliliters;
  #usage;
  #gender;

  /**
  * @param {string} name
  * @param {string} brand
  * @param {number} price
  * @param {Gender} gender
  * @param {number} milliliters
  * @param {Usage} usage
  */
  constructor(name, brand, price, gender, milliliters, usage) {

    super(name, brand, price, gender);

    if (milliliters <= Shampoo.#minMilliliters) {
      throw new Error(`Milliliters must be greater than ${this.minMilliliters}!`)
    }

    if (!Object.keys(Usage).some(key => Usage[key] === usage)) {
      throw new Error(`Invalid gender type value ${usage}!`)
    }

    this.#milliliters = milliliters;
    this.#usage = usage;
  }

  get milliliters() {
    return this.#milliliters
  }

  get usage() {
    return this.#usage
  }

  get gender() {
    return this.#gender
  }

  print() {

    return super.print();
  }

  additionalInfo() {
    return ` #Milliliters: ${this.#milliliters}\n` +
      ` #Usage: ${this.usage}`;
  }
}