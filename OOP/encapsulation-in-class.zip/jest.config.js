/* eslint-disable no-undef */
export default {
  verbose: true,
  transform: {
    '^.+\\.jsx?$': 'babel-jest',
  },
};
