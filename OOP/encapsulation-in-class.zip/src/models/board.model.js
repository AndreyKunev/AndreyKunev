import { Task } from './task.model.js';

/** The Board class holds tasks */
export class Board {
  #tasks;

  /** Adds a new task to the board. */
  add(task) {
    // missing implementation
  }
  
  /** Removes a task from the board. */
  remove(task) {
    // missing implementation
  }

  /** Transforms the board data into a formatted string. */
  toString() {
    const titles = '---Task Board---\n\nTasks:\n\n';

    if (this.#tasks.length) {
      return titles + this.#tasks.join('\n--------\n');
    }

    return `${titles}No tasks at the moment.`;
  }
}
