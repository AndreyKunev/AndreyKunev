import { status } from '../common/status.enum.js';

/** The Task class holds all relevant data and behavior a task might have. */
export class Task {
  // One way to indicate that a field should not be touched is to put an underscore before its name.
  // This won't prevent your colleges from directly interacting with it.

  #name;
  #dueDate;
  #status;

  /** Sets the task status to TODO. */
  reset() {
    // missing implementation
  }

  /** Sets the task status to IN_PROGRESS. */
  advance() {
    // missing implementation
  }

  /** Sets the task status to DONE. */
  complete() {
    // missing implementation
  }

  /** Transforms the task data into a formatted string */
  toString() {
    return `Name: ${this.#name}\n` + 
           `Status: ${this.#status}\n` +
           `Due: ${this.#dueDate.toLocaleDateString()} ${this.#dueDate.toLocaleTimeString()}`;
  }
}
